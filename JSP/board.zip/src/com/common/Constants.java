package com.common;

public class Constants {
    public final static String BASIC_VIEW_PATH = "/WEB-INF/views/" ;
}
